#include <stdio.h>

int main()
{
    printf("Hello 1190200523石翔宇\n");
    return 0;
}